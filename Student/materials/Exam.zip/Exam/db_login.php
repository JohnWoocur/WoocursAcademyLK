<?php 
session_start();
require 'db_connection.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  
     $Username =$_POST['name'];
     $Password=$_POST['password'];
    }
     $query="SELECT * FROM  user WHERE User_name='$Username'";
     $result = mysqli_query($conn,$query);
 
     if(mysqli_num_rows($result)==1){ 
         $row=mysqli_fetch_assoc($result);
         $name=$row["User_name"];

 
         if($Password==$row["Password"]){
            $_SESSION["id"]=$name;
             header("location:home.php");
             
         }
         
         else{
            $_SESSION['error']="Password wrong";
            echo "login failed";
            header("location:login.php"); 
         }
     }
     else{
        $_SESSION['error']="E-mail wrong";
        header("location:login.php");
     }

?>