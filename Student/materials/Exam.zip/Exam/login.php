
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  
    <center>
    <div>
        <table bgcolor="Gray"  style="width:25%">
        <form  action="db_login.php" method="POST">
            
              
                <tr>
                    <td> <label>Username</label></td>
                    <td> <input type="text" name="name" required></td>
                </tr>
                <tr>
                    <td> <label>Password</label></td>
                    <td> <input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td> <button type="submit">Login</button></td>
				    <td> <a href="register.php">Don't have an account ?</a></td>
                </tr>
        </form>
        </table>
    </div>
    </center>
   
</body>
</html>