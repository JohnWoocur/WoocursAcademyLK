<?php 
require 'db_connection.php';

$Username=$_POST['name'];
$Password=$_POST['password']; 
$Email=$_POST['mail'];

$query="INSERT INTO `user`(`User_name`, `Password`, `Email`) VALUES('$Username','$Password','$Email')";
$result=mysqli_query($conn,$query);
if($result){
    header('location:login.php');
}
else{
    header('location:register.php');
}

?>